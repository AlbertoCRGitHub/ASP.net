﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Exercice_4.Extensions;
using Exercice_4.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;

namespace Exercice_4.Controllers
{
    public class ÉtudiantController : Controller
    {

        // GET: Étudiant
        public ActionResult Index()
        {
            //à faire : Retrouver la liste d'étudiants en session et envoyer celle-ci en paramètre à la vue.
            //List<Étudiant> étudiants = ObtenirListeEtudiants();
           // return View(étudiants);

            //or
            return View(ObtenirListeEtudiants());
        }

        // GET: Étudiant/Details/5
        public ActionResult Details(int id)
        {
        //à faire : Retrouver l'étudiant dans la liste en session et envoyer celui-ci en paramètre à la vue.
            
            return View(RetrouverEtudiantParId(id));
        }

        // GET: Étudiant/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Étudiant/Create
        [HttpPost]
        public ActionResult Create(Étudiant étudiant)
        {
                                                //à faire : Ajouter le nouvel étudiant à la liste en session. Rediriger ensuite vers l'index.
            CreerEtudiant(étudiant);
            return RedirectToAction("Index", "Étudiant");
        }

        // GET: Étudiant/Edit/5
        public ActionResult Edit(int id)
        {
                                                        //à faire : Retrouver l'étudiant dans la liste en session et envoyer celui-ci en paramètre à la vue.
            return View(RetrouverEtudiantParId(id));
        }

        // POST: Étudiant/Edit/5
        [HttpPost]
        public ActionResult Edit(Étudiant étudiant)
        {
                                                         //à faire : Retrouver l'étudiant dans la liste en session et modifier ses propriétés. Rediriger ensuite vers l'index.
            ModifierEtudiant(étudiant);
            return RedirectToAction("Index", "Étudiant");
        }

        // GET: Étudiant/Delete/5
        public ActionResult Delete(int id)
        {
            //à faire : Retrouver l'étudiant dans la liste en session et le retirer de la liste. Rediriger ensuite vers l'index.
            RetirerEtudiantParId(id);
            return RedirectToAction("Index", "Étudiant");
        }

        public List<Étudiant> ObtenirListeEtudiants()
        {
            List<Étudiant> etudiants = HttpContext.Session.Get<List<Étudiant>>("Etudiants") ?? new List<Étudiant>();

            if (etudiants.Count == 0)
            {
                Étudiant etudiant1 = new Étudiant
                {
                    ÉtudiantID = 1,
                    Âge = 18,
                    Courriel = "shuot@gmail.com",
                    Matricule = "12345",
                    Nom = "Huot",
                    Prénom = "Sébastien",
                    Programme = "Informatique",
                    Téléphone = "(514)265-0987"
                };

                Étudiant etudiant2 = new Étudiant
                {
                    ÉtudiantID = 2,
                    Âge = 22,
                    Courriel = "jpoitras@gmail.com",
                    Matricule = "123455",
                    Nom = "Poitras",
                    Prénom = "Jean",
                    Programme = "Informatique",
                    Téléphone = "(514)265-0987"
                };

                Étudiant etudiant3 = new Étudiant
                {
                    ÉtudiantID = 3,
                    Âge = 24,
                    Courriel = "korn@gmail.com",
                    Matricule = "1235",
                    Nom = "Tremblay",
                    Prénom = "Hugo",
                    Programme = "Administration",
                    Téléphone = "(514)675-0987"
                };

                Étudiant etudiant4 = new Étudiant
                {
                    ÉtudiantID = 4,
                    Âge = 18,
                    Courriel = "paul@gmail.com",
                    Matricule = "12322",
                    Nom = "Joly",
                    Prénom = "Paul",
                    Programme = "Art",
                    Téléphone = "(514)265-0987"
                };

                etudiants.Add(etudiant1);
                etudiants.Add(etudiant2);
                etudiants.Add(etudiant3);
                etudiants.Add(etudiant4);

                HttpContext.Session.Set<List<Étudiant>>("Etudiants", etudiants);
            }

            return etudiants;
        }

        public Étudiant RetrouverEtudiantParId(int ID)
        {
            List<Étudiant> etudiants = HttpContext.Session.Get<List<Étudiant>>("Etudiants");
            Étudiant Étudiant = etudiants.Find(etud => etud.ÉtudiantID == ID);

            return Étudiant;
        }

        public void RetirerEtudiantParId(int ID)
        {
            List<Étudiant> etudiants = HttpContext.Session.Get<List<Étudiant>>("Etudiants");
            etudiants.RemoveAll(Étudiant => Étudiant.ÉtudiantID == ID);

            HttpContext.Session.Set<List<Étudiant>>("Etudiants", etudiants);
        }

        public void CreerEtudiant(Étudiant p_etudiant)
        {
            List<Étudiant> etudiants = HttpContext.Session.Get<List<Étudiant>>("Etudiants") ?? ObtenirListeEtudiants();
            etudiants.Add(p_etudiant);
            HttpContext.Session.Set<List<Étudiant>>("Etudiants", etudiants);
        }

        public void ModifierEtudiant(Étudiant p_etudiant)
        {
            List<Étudiant> etudiants = HttpContext.Session.Get<List<Étudiant>>("Etudiants") ?? ObtenirListeEtudiants();
            int index = etudiants.FindIndex(et => et.ÉtudiantID == p_etudiant.ÉtudiantID);
            etudiants[index] = p_etudiant;

            HttpContext.Session.Set<List<Étudiant>>("Etudiants", etudiants);
        }
    }
}