﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel;

namespace Exercice_4.Models
{
    public class Étudiant
    {
        [Required(ErrorMessage = "L'id de l'étudiant est requis")]
        public int ÉtudiantID { get; set; }
        [Required(ErrorMessage = "Le prénom de l'étudiant est requis")]
        public string Prénom { get; set; }
        [Required(ErrorMessage = "Le nom de l'étudiant est requis")]
        public string Nom { get; set; }
        public int Âge { get; set; }
        [EmailAddress(ErrorMessage = "Veuillez saisir une adresse courriel valide")]
        public string Courriel { get; set; }
        
        public string Matricule { get; set; }
        public string Programme { get; set; }
        public string Téléphone { get; set; }

        public static implicit operator Étudiant(List<Étudiant> v)
        {
            throw new NotImplementedException();
        }
    }
}
